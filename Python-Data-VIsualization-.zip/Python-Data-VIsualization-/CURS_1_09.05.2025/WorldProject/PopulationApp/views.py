from django.shortcuts import render
import matplotlib.pyplot as plt 
from io import BytesIO
import base64
import matplotlib
# Create your views here.

matplotlib.use("svg")

def all_countries_view(request):
	context = {}
	return render(request, 'all_countries.html', context)

def create_image():
	countries = ["China", "India"]
	population = [1411, 1378]
	fig, axes = plt.subplot()
	fig.pie(population, labels=countries)
	buffer = BytesIO()
	fig.savefig(buffer, format = "png")
	buffer.seek(0)
	image_png = buffer.getvalue()
	buffer.close()

	base64.b64encode(image_png).decode("utf-8")

	# tari = "China_India.png"
	# path = "PopulationApp/static/"
	# image_path = path + tari
	# plt.savefig(image_path)
	#return image_path

def choose_countries_view(request):
	countries = ['Bangladesh', 'Brazil', 'China', 'India', 'Indonesia', 'Mexico', 'Nigeria', 'Pakistan', 'Russia', 'United States']
	population = [170, 213, 1411, 1378, 271, 126, 211, 225, 146, 331]

	result_image = '10_tari.png'
	base64_image = None

	if request.method == "POST":
		print("parametrii:", request.POST.keys())

		base64_image = create_image()
	context = {
		'countries': countries,
		'result_image': result_image,
		'base64_image': base64_image,
	}
	return render(request, 'choose_countries.html', context)

