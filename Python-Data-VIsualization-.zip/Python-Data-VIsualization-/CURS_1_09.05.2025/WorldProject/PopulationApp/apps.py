from django.apps import AppConfig


class PopulationappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'PopulationApp'

