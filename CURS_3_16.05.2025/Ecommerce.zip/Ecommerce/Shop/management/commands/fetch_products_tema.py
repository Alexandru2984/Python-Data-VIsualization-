

### Luati un produs si il puneti in database, sa includa nume, descriere, slug, pret si imagine

### Luati 10 produse si le puneti in database

def products_db():
    pass